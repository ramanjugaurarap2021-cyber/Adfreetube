# YouTube Player

A small open-source Android app that embeds YouTube's official player in a custom Android UI.

It accepts a YouTube URL or 11-character video ID and loads the video using the official YouTube embed endpoint.

This project does not extract or proxy YouTube media streams and does not attempt to remove or bypass YouTube advertising/access controls.
